package edu.school.tests;

import java.awt.Color;

import edu.school.models.SVGCircle;
import edu.school.models.SVGLine;
import edu.school.models.SVGPicture;
import edu.school.models.SvgEllipse;
import edu.school.models.SvgPolygon;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SVGPicture pic = new SVGPicture();
		//pic.add(new SVGLine(10, 10, 180, 250, Color.red, 5));
		//pic.add(new SVGLine(280, 10, 0, 368, Color.blue, 1));
		//System.out.println(pic);
		
		//pic.add(new SvgEllipse(200,80,100,50,Color.yellow,Color.blue,2));
		
		//pic.add(new SVGCircle(50, 50, 40,Color.black,3,Color.green));
		
		pic.add(new SvgPolygon(100 , 10 , 5 ,Color.blue,Color.green, 1, "evenodd"));
		System.out.println(pic);
	}

}
