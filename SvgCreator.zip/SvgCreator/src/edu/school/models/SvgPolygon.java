package edu.school.models;

import java.awt.Color;
import java.util.Scanner;

public class SvgPolygon extends SVGObject {

	private Color fill;
	private int strokeWidth;
	private String fillRule;
	private int numberOfCorners;
	
	public SvgPolygon(int startX, int startY,int numberOfCorners,
			Color fill,Color strokeColor, int strokeWidth,String fillRule)
	{
		super(startX,startY,strokeColor);
		setFillRule(fillRule);
		setStrokeWidth(strokeWidth);
		setFill(fill);
		setNumberOfCorners(numberOfCorners);
	}
	
	public Color getFill() {
		return fill;
	}

	public void setFill(Color fill) {
		this.fill = fill;
	}

	public int getStrokeWidth() {
		return strokeWidth;
	}

	public void setStrokeWidth(int strokeWidth) {
		this.strokeWidth = strokeWidth;
	}

	public String getFillRule() {
		return fillRule;
	}

	public void setFillRule(String fillRule) {
		this.fillRule = fillRule;
	}
	
	public int getNumberOfCorners() {
		return numberOfCorners;
	}

	public void setNumberOfCorners(int numberOfCorners) {
		this.numberOfCorners = numberOfCorners;
	}

	Scanner input1 = new Scanner(System.in);
	Scanner input2 = new Scanner(System.in);
	
	@Override
	public String toSvgCode() {
        String result = "<polygon ";
        result+="points = \""+ getX() + "," + getY() + " ";
        for(int i = 0 ; i < numberOfCorners - 1; i++) {
        	double x = input1.nextDouble();
        	double y = input2.nextDouble();
        	result+=x + "," + y + " ";
        }
        result += "\" style = " ;
        result += "\"fill:" + toRGB(getFill()) + "; stroke:" + toRGB(getColor()) +"; stroke-width:" + getStrokeWidth()+
        		"; fill-rule:" + getFillRule() + ";\"/>";
		 return result;
	}

}
