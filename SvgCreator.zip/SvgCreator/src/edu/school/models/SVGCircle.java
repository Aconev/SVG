package edu.school.models;

import java.awt.Color;

public class SVGCircle extends SVGObject{

	private int radius;
    private Color stroke;
    private int strokeWidth;


    public SVGCircle(int x,int y,  int radius, Color stroke, int strokeWidth, Color fillColor) {
        super(x,y,fillColor);
        setRadius(radius);
        setStroke(stroke);
        setStrokeWidth(strokeWidth);
    }

    public void setRadius(int radius) {
        if(radius > 0) {
            this.radius = radius;
        }
    }

    public void setStroke(Color stroke) {
        this.stroke = stroke;
    }


    public void setStrokeWidth(int strokeWidth) {
        if(strokeWidth >= 0) {
            this.strokeWidth = strokeWidth;
        }
    }

    public int getRadius() {
        return radius;
    }


    public Color getStroke() {
        return stroke;
    }

    public int getStrokeWidth() {
        return strokeWidth;
    }
    
    @Override
    public String toSvgCode() {
        String result = "<circle ";
        result+="cx = \""+getX()+"\"cy=\""+getY()+"\"";
        result += "r=\"" + getRadius() + "\" stroke=\"" + toRGB(getStroke()) + "\" ";
        result += "stroke-width=\"" + getStrokeWidth() + "\" fill=\"" + toRGB(getColor()) +"\"/>";
        return result;
    }
	
}
