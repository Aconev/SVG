package edu.school.models;

import java.awt.Color;

public class SvgRectangle extends SVGObject {

	private int width;
    private int height;
    private Color stroke;
    private int strokeWidth;
    private double fillOpacity;
    private double strokeOpacity;
	
    public SvgRectangle(int x, int y,int width, int height, Color fill, Color stroke, int strokeWidth,
            double fillOpacity, double strokeOpacity) {
        super(x,y,fill);
        setWidth(width);
        setHeight(height);
        setStroke(stroke);
        setStrokeWidth(strokeWidth);
        setFillOpacity(fillOpacity);
        setStrokeOpacity(strokeOpacity);
    }
    

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Color getStroke() {
		return stroke;
	}

	public void setStroke(Color stroke) {
		this.stroke = stroke;
	}

	public int getStrokeWidth() {
		return strokeWidth;
	}

	public void setStrokeWidth(int strokeWidth) {
		this.strokeWidth = strokeWidth;
	}

	public double getFillOpacity() {
		return fillOpacity;
	}

	public void setFillOpacity(double fillOpacity) {
		this.fillOpacity = fillOpacity;
	}

	public double getStrokeOpacity() {
		return strokeOpacity;
	}

	public void setStrokeOpacity(double strokeOpacity) {
		this.strokeOpacity = strokeOpacity;
	}
	
	@Override
    public String toSvgCode() {
        String result = "<rect ";
        result += "x=\"" + getX() + "\" y=\"" + getY() + "\" width=\"" + getWidth() + "\" height=\"" + getHeight() + "\" ";
        result += "style=\" fill:" + toRGB(getColor()) + ";stroke:" + toRGB(getStroke()) + ";stroke-width:" + getStrokeWidth() + ";";
        result += "fill-opacity:" + getFillOpacity() + ";stroke-opacity:" + getStrokeOpacity() + "\" />";
        return result;
    }

}
