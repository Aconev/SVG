package edu.school.models;

import java.awt.Color;

public class SvgEllipse extends SVGObject{

	private int endX;
	private int endY;
	private int strokeWidth;
	private Color fill;
	
	public SvgEllipse(int startX, int startY, int endX, int endY,
			Color fill,Color strokeColor, int strokeWidth)
	{
		super(startX,startY,strokeColor);
		setEndX(endX);
		setEndY(endY);
		setStrokeWidth(strokeWidth);
		setFill(fill);
	}
	
	public int getEndX() {
		return endX;
	}
	
	public void setEndX(int endX) {
		this.endX = endX;
	}
	
	public int getEndY() {
		return endY;
	}
	
	public void setEndY(int endY) {
		this.endY = endY;
	}
	
	public int getStrokeWidth() {
		return strokeWidth;
	}
	
	public void setStrokeWidth(int strokeWidth) {
		this.strokeWidth = strokeWidth;
	}
	
	public Color getFill() {
		return fill;
	}
	
	public void setFill(Color fill) {
		this.fill = fill;
	}

	@Override
	public String toSvgCode() {
		String result = "<ellipse ";
		result+="cx = \""+getX()+"\"cy=\""+getY()+"\"";
		result+="rx = \""+getEndX()+"\"ry=\""+getEndY()+"\"";
		result+= "style = \"fill:"+toRGB(getFill())+";stroke:"+toRGB(getColor())+";stroke-width:"+getStrokeWidth()+"\"/>";
		return result;
	}
	
	
}
